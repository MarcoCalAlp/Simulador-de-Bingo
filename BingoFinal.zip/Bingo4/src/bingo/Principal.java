/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bingo;


import bingo.estructura.Bingo;
import bingo.estructura.Jugador;
import bingo.estructura.Tablero;

/**
 *
 * @author marcovinicio
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
       Bingo b=new Bingo();
       b.partida();
       
      
       
    }
    
}
