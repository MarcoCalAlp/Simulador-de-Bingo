/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bingo.estructura;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author marcovinicio
 */
public class Jugador {
public List<Tablero> tableros=new ArrayList<Tablero>();
public int cantidadTableros;

 //_________METODOS_______________
    public Jugador() {
       
    }
  //________________________________

    public List<Tablero> getTableros() {
        return tableros;
    }
    //______________________________
    public void setTableros(List<Tablero> tableros) {
        this.tableros = tableros;
    }
    //_______________________________
    public void agregarTablero(int num){
        for(int i=0;i<num;i++){
        Tablero tab=new Tablero();
        tableros.add(tab);
        }
    }
    //________________________________
    
}
