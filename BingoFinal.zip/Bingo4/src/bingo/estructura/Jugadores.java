/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bingo.estructura;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 *
 * @author marcovinicio
 */
public class Jugadores {
    
public List<Jugador> jugadores=new ArrayList<Jugador>();


 //_________METODOS_______________

    public Jugadores() {
    }
    //____________________________
    public List<Jugador> getJugadores() {
        return jugadores;
    }
    //____________________________
    public void setJugadores(List<Jugador> jugadores) {
        this.jugadores = jugadores;
    }
    //____________________________
    
    public void agregarJugador(int num,int tab){
        Random rnd=new Random();
        for(int i=0;i<num;i++){
        int r=(int)(rnd.nextDouble() * tab + 1);
        Jugador j=new Jugador();
        j.agregarTablero(r);
        jugadores.add(j);
        }
    }
    
    //________________________________
    

}
