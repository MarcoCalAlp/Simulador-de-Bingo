/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bingo.estructura;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.Random;
import java.util.Scanner;
import java.util.stream.IntStream;

/**
 *
 * @author marcovinicio
 */
public class Bingo {
public final static String MENSAJE="BINGOOOO HAS GANADO";
private int[] bolita= IntStream.rangeClosed(1, 75).toArray();
private Juego jug;
private Jugador j1;
private Jugadores jes;
//-----METODOS---------------------------
    public Bingo() {
        jug=new Juego();
        jes=new Jugadores();
        init();
    }
//--------------------------------------
    public void agregarJugadores(int jug,int tab){
        jes.agregarJugador(jug,tab);
    }
//---------------------------------------
    public void init(){
        for(int i=0;i<75;i++){
            bolita[i]=i+1;
        }
        desordenar();
    }
//---------------------------------------
    public void desordenar(){
        Random r = new Random();
        for (int i = bolita.length; i>0; i--) {
        int posicion = r.nextInt(i);
        int tmp = bolita[i-1];
        bolita[i - 1] = bolita[posicion];
        bolita[posicion] = tmp;
        }
    }
//----------------------------------------
    public void imprimir(){
    System.out.println("Numeros[0,75]");
    System.out.print("[");
    for(int i=0;i<65;i++){
        System.out.print(bolita[i]+",");
    }
    System.out.print("]");
    }
//----------------------------------------
    public void jugar(int sel,int jugs,int tabs){
        agregarJugadores(jugs,tabs);
        String aux;
        switch(sel){
            //----------------------------------
            case Juego.HORIZONTAL:
            for(int i=0;i<75;i++){
                tipo(bolita[i]);
                aux=String.valueOf(bolita[i]);
                if(jug.Horizontal(aux, jes)==1){
                    System.out.println(MENSAJE);
                    break;
                }  
            }
            break;
            //----------------------------------
            case Juego.VERTICAL:
            for(int i=0;i<75;i++){
                tipo(bolita[i]);
                aux=String.valueOf(bolita[i]);
                if(jug.Vertical(aux, jes)==1){
                    System.out.println(MENSAJE);
                    break;
                }  
            }
            break;
            //----------------------------------
            case Juego.DIAGONAL:
            for(int i=0;i<75;i++){
                tipo(bolita[i]);
                aux=String.valueOf(bolita[i]);
                if(jug.Diagonal(aux, jes)==1){
                    System.out.println(MENSAJE);
                    break;
                }  
            }
            break;
            //----------------------------------
            case Juego.C:
            for(int i=0;i<75;i++){
                tipo(bolita[i]);
                aux=String.valueOf(bolita[i]);
                if(jug.C(aux, jes)==1){
                    System.out.println(MENSAJE);
                    break;
                }  
            }
            //----------------------------------
            case Juego.X:
            for(int i=0;i<75;i++){
                tipo(bolita[i]);
                aux=String.valueOf(bolita[i]);
                if(jug.X(aux, jes)==1){
                    System.out.println(MENSAJE);
                    break;
                }  
            }
            break;
            //----------------------------------
            case Juego.O:
            for(int i=0;i<75;i++){
                tipo(bolita[i]);
                aux=String.valueOf(bolita[i]);
                if(jug.O(aux, jes)==1){
                    System.out.println(MENSAJE);
                    break;
                }  
            }
            break;
            //----------------------------------
            case Juego.U:
            for(int i=0;i<75;i++){
                tipo(bolita[i]);
                aux=String.valueOf(bolita[i]);
                if(jug.U(aux, jes)==1){
                    System.out.println(MENSAJE);
                    break;
                }  
            }
            break;
            //----------------------------------
            case Juego.BINGO:
            for(int i=0;i<75;i++){
                tipo(bolita[i]);
                aux=String.valueOf(bolita[i]);
                if(jug.BINGO(aux, jes)==1){
                    System.out.println(MENSAJE);
                    break;
                }  
            }
            break;
            //----------------------------------
            default:
                System.out.println("--> ERROR <--");
                break;
        }
        
    }
    //____________________________________
    public void tipo(int num){
        if(num>0&&num<16){
            System.out.println("B"+num);
        }
        if(num>=16&&num<31){
            System.out.println("I"+num);
        }
        if(num>=31&&num<46){
            System.out.println("N"+num);
        }
        if(num>=46&&num<61){
            System.out.println("G"+num);
        }
        if(num>=61&&num<76){
            System.out.println("O"+num);
        }
    }
    //____________________________________
    public void partida(){
    Scanner capt = new Scanner(System.in);
    System.out.println("Digite el numero de Jugadores: ");
    int a = capt.nextInt();
    System.out.println("Digite la cantidad maxima de cartones por jugador: ");
    int b = capt.nextInt();
    System.out.println("Digite el numero que corresponde al tipo de juego deseado: ");
    tipoJuego();
    int c = capt.nextInt();
    jugar(c,a,b);
    this.archivo();
    }
    //____________________________________
    public void tipoJuego(){
     System.out.println("=====================");
     System.out.println("= -> HORIZONTAL : 0 =");
     System.out.println("= -> VERTICAL : 1   =");
     System.out.println("= -> DIAGONAL : 2   =");
     System.out.println("= -> C : 3          =");
     System.out.println("= -> X : 4          =");
     System.out.println("= -> O : 5          =");
     System.out.println("= -> U : 6          =");
     System.out.println("= -> BINGO : 7      =");
     System.out.println("=====================");
    }
    //____________________________________
    public void archivo(){
    jug.archivo();
    }

}
