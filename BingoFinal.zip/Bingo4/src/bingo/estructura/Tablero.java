/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bingo.estructura;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.stream.IntStream;

/**
 *
 * @author marcovinicio
 */
public class Tablero {
private int[] numerosAleatoriosB= IntStream.rangeClosed(1, 15).toArray();
private int[] numerosAleatoriosI= IntStream.rangeClosed(16, 30).toArray();
private int[] numerosAleatoriosN= IntStream.rangeClosed(31, 45).toArray();
private int[] numerosAleatoriosG=IntStream.rangeClosed(46, 60).toArray();
private int[] numerosAleatoriosO =IntStream.rangeClosed(61, 75).toArray();
private List<String> B= new ArrayList<String>();
private List<String> I= new ArrayList<String>();
private List<String> N= new ArrayList<String>();
private List<String> G= new ArrayList<String>();
private List<String> O= new ArrayList<String>();
//_____METODOS___________________________

public Tablero() {
init();
initTablero();
}

//_______________________________________
 public void init(){
   for(int i=0;i<15;i++){
     numerosAleatoriosB[i]=i+1;
        if(i==0){
         numerosAleatoriosI[i]=16;
         numerosAleatoriosN[i]=31;
         numerosAleatoriosG[i]=46;
         numerosAleatoriosO[i]=61;
        }
        else{
         numerosAleatoriosI[i]=16+i;
         numerosAleatoriosN[i]=31+i;
         numerosAleatoriosG[i]=46+i;
         numerosAleatoriosO[i]=61+i;
        }
    } 
   desordenar();
}
//________________________________________
 public void desordenar(){
Random r = new Random();
//------CASO B---------------
    for (int i = numerosAleatoriosB.length; i>0; i--) {
        int posicion = r.nextInt(i);
        int tmp = numerosAleatoriosB[i-1];
        numerosAleatoriosB[i - 1] = numerosAleatoriosB[posicion];
        numerosAleatoriosB[posicion] = tmp;
    }
//------CASO I---------------
   for (int i = numerosAleatoriosI.length; i > 0; i--) {
        int posicion = r.nextInt(i);
        int tmp = numerosAleatoriosI[i-1];
        numerosAleatoriosI[i - 1] = numerosAleatoriosI[posicion];
        numerosAleatoriosI[posicion] = tmp;
    }
//------CASO N---------------
    for (int i = numerosAleatoriosN.length; i > 0; i--) {
        int posicion = r.nextInt(i);
        int tmp = numerosAleatoriosN[i-1];
        numerosAleatoriosN[i - 1] = numerosAleatoriosN[posicion];
        numerosAleatoriosN[posicion] = tmp;
    }
//------CASO G---------------
    for (int i = numerosAleatoriosG.length; i > 0; i--) {
        int posicion = r.nextInt(i);
        int tmp = numerosAleatoriosG[i-1];
        numerosAleatoriosG[i - 1] = numerosAleatoriosG[posicion];
        numerosAleatoriosG[posicion] = tmp;
    }
//------CASO O---------------
   for (int i = numerosAleatoriosO.length; i > 0; i--) {
        int posicion = r.nextInt(i);
        int tmp = numerosAleatoriosO[i-1];
        numerosAleatoriosO[i - 1] = numerosAleatoriosO[posicion];
        numerosAleatoriosO[posicion] = tmp;
    }

}   

//__________________________________________
    public void initTablero(){
       String auxB,auxI,auxN,auxG,auxO;
        for(int i=0;i<5;i++){
        auxB=String.valueOf(numerosAleatoriosB[i]);    
        B.add(auxB);
        auxI=String.valueOf(numerosAleatoriosI[i]);
        I.add(auxI);
        auxN=String.valueOf(numerosAleatoriosN[i]);
        N.add(auxN);
        auxG=String.valueOf(numerosAleatoriosG[i]);
        G.add(auxG);
        auxO=String.valueOf(numerosAleatoriosO[i]);
        O.add(auxO);
        }
    }
//___________________________________________
    public void imprimeTablero(int jug,int tab){
        System.out.println("=======Jugador#"+(jug)+"====================");
        System.out.println("--------Tablero#"+(tab)+"-------------------");
        System.out.println("B"+" "+" I"+" "+" N"+" "+" G"+" "+" O");
        for(int i=0;i<5;i++){
            System.out.println(B.get(i)+" "+I.get(i)+" "+N.get(i)+" "+G.get(i)+" "+O.get(i)+" ");
        }
        System.out.println("-----------------------------------------");
        System.out.println("========================================");
    }
//___________________________________________
    public String imprime(int jug,int tab){
      String tabla="<p>=======Jugador#"+(jug)+"====================</p>";
      tabla+="<p>--------Tablero#"+(tab)+"-------------------</p>";
      tabla+="<p>B"+" "+" I"+" "+" N"+" "+" G"+" "+" O</p>";
      for(int i=0;i<5;i++){
            tabla+="<p>"+B.get(i)+" "+I.get(i)+" "+N.get(i)+" "+G.get(i)+" "+O.get(i)+" "+"</p>";
        }
      tabla+="<p>-----------------------------------------</p>";
      tabla+="<p>========================================</p>";
      return tabla;  
    }
//___________________________________________

    public List<String> getB() {
        return B;
        
    }

    public List<String> getI() {
        return I;
    }

    public List<String> getN() {
        return N;
    }

    public List<String> getG() {
        return G;
    }

    public List<String> getO() {
        return O;
    }
//___________________________________    

}
