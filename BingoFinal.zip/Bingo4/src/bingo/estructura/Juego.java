/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bingo.estructura;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author marcovinicio
 */
public class Juego {
public final static int HORIZONTAL=0;
public final static int VERTICAL=1;
public final static int DIAGONAL=2;
public final static int C=3;
public final static int X=4;
public final static int O=5;
public final static int U=6;
public final static int BINGO=7;
private String ganadorHTML;
private String tablaHTML;
private String cantJugadorHTML;
private String juegoHTML;
private String recorridoHTML=" ";
//----------METODOS---------------------

    public Juego() {
    }
//--------------------------------------    
    public int Horizontal(String num,Jugadores jes){
        juegoHTML="<p>=====>Tipo de Juego: HORIZONTAL</p>";
        recorre(num,jes);
        try {
                Thread.sleep(500);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        int flag=0;
    for(int t=0;t<jes.getJugadores().size();t++){
        cantJugadorHTML="<p>======>Cantidad de jugadores registrados:"+jes.getJugadores().size()+"</p>";
        List<Tablero> aux=jes.getJugadores().get(t).getTableros();
        for(int j=0;j<aux.size();j++){  
            Tablero tab = aux.get(j);
              for(int i=0;i<5;i++)
              {
                  if(tab.getB().get(i).equals("x")&&tab.getI().get(i).equals("x")&&tab.getN().get(i).equals("x")&&tab.getG().get(i).equals("x")
                   &&tab.getO().get(i).equals("x")){
                      tablaHTML=tab.imprime(t+1,j+1);
                      System.out.println("======JUGADOR GANADOR-->"+(t+1)+" ===="+"Tablero ganador Del jugador: N"+(j+1)+"====");
                      ganadorHTML="======JUGADOR GANADOR-->"+(t+1)+" ===="+"Tablero ganador Del jugador: N"+(j+1)+"====";
                      return 1;//flag=1;
                  }
              }
        }
    }
        return flag;
    }
//--------------------------------------    
    public int Vertical(String num,Jugadores jes){
        juegoHTML="<p>=====>Tipo de Juego:VERTICAL</p>";
        recorre(num,jes);
        int flag=0;
        try {
                Thread.sleep(500);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
     for(int t=0;t<jes.getJugadores().size();t++){
         cantJugadorHTML="<p>======>Cantidad de jugadores registrados:"+jes.getJugadores().size()+"</p>";
        List<Tablero> aux=jes.getJugadores().get(t).getTableros();
        for(int j=0;j<aux.size();j++){  
            Tablero tab = aux.get(j);
            if(tab.getB().get(0).equals("x")&&tab.getB().get(1).equals("x")&&tab.getB().get(2).equals("x")&&tab.getB().get(3).equals("x")&&tab.getB().get(4).equals("x")
            ||tab.getI().get(0).equals("x")&&tab.getI().get(1).equals("x")&&tab.getI().get(2).equals("x")&&tab.getI().get(3).equals("x")&&tab.getI().get(4).equals("x")
            ||tab.getN().get(0).equals("x")&&tab.getN().get(1).equals("x")&&tab.getN().get(2).equals("x")&&tab.getN().get(3).equals("x")&&tab.getN().get(4).equals("x")
            ||tab.getG().get(0).equals("x")&&tab.getG().get(1).equals("x")&&tab.getG().get(2).equals("x")&&tab.getG().get(3).equals("x")&&tab.getG().get(4).equals("x")
            ||tab.getO().get(0).equals("x")&&tab.getO().get(1).equals("x")&&tab.getO().get(2).equals("x")&&tab.getO().get(3).equals("x")&&tab.getO().get(4).equals("x")){
                tablaHTML=tab.imprime(t+1,j+1);
                System.out.println("======JUGADOR GANADOR-->"+(t+1)+" ===="+"Tablero ganador Del jugador: N"+(j+1)+"====");
                ganadorHTML="======JUGADOR GANADOR-->"+(t+1)+" ===="+"Tablero ganador Del jugador: N"+(j+1)+"====";
                return 1;//flag=1;
            }
        }
     }
        return flag;
    }
//--------------------------------------    
    public int Diagonal(String num,Jugadores jes){
        juegoHTML="<p>=====>Tipo de Juego:DIAGONAL</p>";
        recorre(num,jes);
        int flag=0;
        try {
                Thread.sleep(500);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
    for(int t=0;t<jes.getJugadores().size();t++){
        cantJugadorHTML="<p>======>Cantidad de jugadores registrados:"+jes.getJugadores().size()+"</p>";
        List<Tablero> aux=jes.getJugadores().get(t).getTableros();
        for(int j=0;j<aux.size();j++){  
            Tablero tab = aux.get(j);
            if(tab.getB().get(0).equals("x")&&tab.getI().get(1).equals("x")&&tab.getN().get(2).equals("x")&&tab.getG().get(3).equals("x")&&tab.getO().get(4).equals("x")
            ||tab.getB().get(4).equals("x")&&tab.getI().get(3).equals("x")&&tab.getN().get(2).equals("x")&&tab.getG().get(1).equals("x")&&tab.getO().get(0).equals("x")){
                tablaHTML=tab.imprime(t+1,j+1);
                System.out.println("======JUGADOR GANADOR-->"+(t+1)+" ===="+"Tablero ganador Del jugador: N"+(j+1)+"====");
                ganadorHTML="======JUGADOR GANADOR-->"+(t+1)+" ===="+"Tablero ganador Del jugador: N"+(j+1)+"====";
                return 1; //flag=1;
            }
        }
    } 
        return flag;
        
    }
//--------------------------------------    
    public int C(String num,Jugadores jes){
    juegoHTML="<p>=====>Tipo de Juego:C</p>";
    recorre(num,jes);
    int flag=0;
    try {
            Thread.sleep(500);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    for(int t=0;t<jes.getJugadores().size();t++){
        cantJugadorHTML="<p>======>Cantidad de jugadores registrados:"+jes.getJugadores().size()+"</p>";
        List<Tablero> aux=jes.getJugadores().get(t).getTableros();
        for(int j=0;j<aux.size();j++){  
            Tablero tab = aux.get(j);
            if(tab.getB().get(0).equals("x")&&tab.getI().get(0).equals("x")&&tab.getN().get(0).equals("x")&&tab.getG().get(0).equals("x")&&tab.getO().get(0).equals("x")
            &&tab.getB().get(1).equals("x")&&tab.getB().get(2).equals("x")&&tab.getB().get(3).equals("x")&&tab.getB().get(4).equals("x")
            &&tab.getI().get(4).equals("x")&&tab.getN().get(4).equals("x")&&tab.getG().get(4).equals("x")&&tab.getO().get(4).equals("x")){
                tablaHTML=tab.imprime(t+1,j+1);
                System.out.println("======JUGADOR GANADOR-->"+(t+1)+" ===="+"Tablero ganador Del jugador: N"+(j+1)+"====");
                ganadorHTML="======JUGADOR GANADOR-->"+(t+1)+" ===="+"Tablero ganador Del jugador: N"+(j+1)+"====";
                return 1;//flag=1;
            }
        }
    }
        return flag;
    }
//--------------------------------------    
    public int X(String num,Jugadores jes){
    juegoHTML="<p>=====>Tipo de Juego:X</p>";
    recorre(num,jes);
    int flag=0;
    try {
            Thread.sleep(500);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    for(int t=0;t<jes.getJugadores().size();t++){
        cantJugadorHTML="<p>======>Cantidad de jugadores registrados:"+jes.getJugadores().size()+"</p>";
        List<Tablero> aux=jes.getJugadores().get(t).getTableros();
        for(int j=0;j<aux.size();j++){  
            Tablero tab = aux.get(j);
            if(tab.getB().get(0).equals("x")&&tab.getI().get(1).equals("x")&&tab.getN().get(2).equals("x")&&tab.getG().get(3).equals("x")&&tab.getO().get(4).equals("x")
            &&tab.getB().get(4).equals("x")&&tab.getI().get(3).equals("x")&&tab.getG().get(1).equals("x")&&tab.getO().get(0).equals("x")){
                tablaHTML=tab.imprime(t+1,j+1);
                System.out.println("======JUGADOR GANADOR-->"+(t+1)+" ===="+"Tablero ganador Del jugador: N"+(j+1)+"====");
                ganadorHTML="======JUGADOR GANADOR-->"+(t+1)+" ===="+"Tablero ganador Del jugador: N"+(j+1)+"====";
                return 1;//flag=1;
            }
        }
    }
        return flag;
}
//--------------------------------------    
    public int O(String num,Jugadores jes){
        juegoHTML="<p>=====>Tipo de Juego:O</p>";
        recorre(num,jes);
        int flag=0;
        try {
                Thread.sleep(500);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
    for(int t=0;t<jes.getJugadores().size();t++){
        cantJugadorHTML="<p>======>Cantidad de jugadores registrados:"+jes.getJugadores().size()+"</p>";
        List<Tablero> aux=jes.getJugadores().get(t).getTableros();
        for(int j=0;j<aux.size();j++){  
            Tablero tab = aux.get(j);
            if(tab.getB().get(0).equals("x")&&tab.getI().get(0).equals("x")&&tab.getN().get(0).equals("x")&&tab.getG().get(0).equals("x")&&tab.getO().get(0).equals("x")
            &&tab.getB().get(1).equals("x")&&tab.getB().get(2).equals("x")&&tab.getB().get(3).equals("x")
            &&tab.getB().get(4).equals("x")&&tab.getI().get(4).equals("x")&&tab.getN().get(4).equals("x")&&tab.getG().get(4).equals("x")&&tab.getO().get(4).equals("x")
            &&tab.getO().get(1).equals("x")&&tab.getO().get(2).equals("x")&&tab.getO().get(3).equals("x")){
              tablaHTML=tab.imprime(t+1,j+1);
              System.out.println("======JUGADOR GANADOR-->"+(t+1)+" ===="+"Tablero ganador Del jugador: N"+(j+1)+"====");
              ganadorHTML="======JUGADOR GANADOR-->"+(t+1)+" ===="+"Tablero ganador Del jugador: N"+(j+1)+"====";
                return 1;//flag=1;
            }
        }
    }
        return flag;
    }
//--------------------------------------    
    public int U(String num,Jugadores jes){
        juegoHTML="<p>=====>Tipo de Juego:U</p>";
        recorre(num,jes);
        try {
                Thread.sleep(500);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        int flag=0;
    for(int t=0;t<jes.getJugadores().size();t++){
        cantJugadorHTML="<p>======>Cantidad de jugadores registrados:"+jes.getJugadores().size()+"</p>";
        List<Tablero> aux=jes.getJugadores().get(t).getTableros();
        for(int j=0;j<aux.size();j++){  
            Tablero tab = aux.get(j);
            if(tab.getB().get(0).equals("x")&&tab.getB().get(1).equals("x")&&tab.getB().get(2).equals("x")&&tab.getB().get(3).equals("x")
            &&tab.getB().get(4).equals("x")&&tab.getI().get(4).equals("x")&&tab.getN().get(4).equals("x")&&tab.getG().get(4).equals("x")&&tab.getO().get(4).equals("x")
            &&tab.getO().get(0).equals("x")&&tab.getO().get(1).equals("x")&&tab.getO().get(2).equals("x")&&tab.getO().get(3).equals("x")){
                tablaHTML=tab.imprime(t+1,j+1);
                System.out.println("======JUGADOR GANADOR-->"+(t+1)+" ===="+"Tablero ganador Del jugador: N"+(j+1)+"====");
                ganadorHTML="======JUGADOR GANADOR-->"+(t+1)+" ===="+"Tablero ganador Del jugador: N"+(j+1)+"====";
                return 1;//flag=1;
            }
        }
    }
        return flag;
    }
//--------------------------------------    
    public int BINGO(String num,Jugadores jes){
        juegoHTML="<p>=====>Tipo de Juego:BINGO</p>";
            recorre(num,jes);
            try {
                Thread.sleep(500);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
      int flag=0;
    for(int t=0;t<jes.getJugadores().size();t++){
        cantJugadorHTML="<p>======>Cantidad de jugadores registrados:"+jes.getJugadores().size()+"</p>";
        List<Tablero> aux=jes.getJugadores().get(t).getTableros();
        for(int j=0;j<aux.size();j++){  
             Tablero tab = aux.get(j);
              if(tab.getB().get(0).equals("x")&&tab.getI().get(0).equals("x")&&tab.getN().get(0).equals("x")&&tab.getG().get(0).equals("x")&&tab.getO().get(0).equals("x")
               &&tab.getB().get(1).equals("x")&&tab.getI().get(1).equals("x")&&tab.getN().get(1).equals("x")&&tab.getG().get(1).equals("x")&&tab.getO().get(1).equals("x")
               &&tab.getB().get(2).equals("x")&&tab.getI().get(2).equals("x")&&tab.getN().get(2).equals("x")&&tab.getG().get(2).equals("x")&&tab.getO().get(2).equals("x")
               &&tab.getB().get(3).equals("x")&&tab.getI().get(3).equals("x")&&tab.getN().get(3).equals("x")&&tab.getG().get(3).equals("x")&&tab.getO().get(3).equals("x")
               &&tab.getB().get(4).equals("x")&&tab.getI().get(4).equals("x")&&tab.getN().get(4).equals("x")&&tab.getG().get(4).equals("x")&&tab.getO().get(4).equals("x")){
                  tablaHTML=tab.imprime(t+1,j+1);
                  System.out.println("======JUGADOR GANADOR-->"+(t+1)+" ===="+"Tablero ganador Del jugador: N"+(j+1)+"====");
                  ganadorHTML="======JUGADOR GANADOR-->"+(t+1)+" ===="+"Tablero ganador Del jugador: N"+(j+1)+"====";
                  return 1;//flag=1;
              }
        }
    }
        return flag; 
    }
//--------------------------------------
    public void recorre(String num,Jugadores jes){
   recorridoHTML+="bolita:"+num;
   for(int t=0;t<jes.getJugadores().size();t++){
       List<Tablero> aux=jes.getJugadores().get(t).getTableros();
        for(int j=0;j<aux.size();j++){//Recorre cada tablero del jugador
            Tablero tab = aux.get(j);
               for(int i=0;i<5;i++){/*Recorre cada numero del tablero segun su letra de lista(B,I,N,G,O). 
                                     Si el numero que entra se encuentra en el tablero, se cambia por una x. */
                   if(tab.getB().get(i).equals(num)){
                      tab.getB().set(i, "x");
                      tab.imprimeTablero(t+1,j+1);
                      recorridoHTML+=tab.imprime(t+1,j+1);
                   }
                   if(tab.getI().get(i).equals(num)){
                     tab.getI().set(i, "x");
                     tab.imprimeTablero(t+1,j+1);
                      recorridoHTML+=tab.imprime(t+1,j+1);
                   }
                   if(tab.getN().get(i).equals(num)){
                      tab.getN().set(i, "x");
                      tab.imprimeTablero(t+1,j+1);
                      recorridoHTML+=tab.imprime(t+1,j+1);
                   }
                   if(tab.getG().get(i).equals(num)){
                      tab.getG().set(i, "x");
                      tab.imprimeTablero(t+1,j+1);
                      recorridoHTML+=tab.imprime(t+1,j+1);
                   }
                   if(tab.getO().get(i).equals(num)){
                      tab.getO().set(i, "x");
                      tab.imprimeTablero(t+1,j+1); 
                      recorridoHTML+=tab.imprime(t+1,j+1);
                   }

               }
        }
   }
        
}
public void archivo(){
    FileOutputStream archivo;
    PrintStream p;
    try {
        archivo= new FileOutputStream("pagina.html");
        p= new PrintStream(archivo);
        p.println(cantJugadorHTML);
        p.println(juegoHTML);
        p.println(recorridoHTML);
        p.println(ganadorHTML);
        p.println(tablaHTML);
        p.close();
	} 
       catch (FileNotFoundException e) {}  
}//   


    
}
